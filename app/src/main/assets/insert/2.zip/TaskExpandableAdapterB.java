package com.heavengifts.hercules.adapter;

import android.content.Context;
import android.graphics.Color;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.heavengifts.hercules.R;
import com.heavengifts.hercules.base.Constants;
import com.heavengifts.hercules.controller.TaskDetailsManager;
import com.heavengifts.hercules.database.DBUtils;
import com.heavengifts.hercules.utils.DensityUtil;
import com.heavengifts.hercules.utils.Utils;
import com.heavengifts.hercules.view.DrawableCenterTextView;

import java.security.acl.Group;
import java.util.ArrayList;
import java.util.HashMap;

import butterknife.ButterKnife;
import butterknife.InjectView;

/**
 * Created by jack.yang on 15/12/9.
 */
public class TaskExpandableAdapterB extends BaseExpandableListAdapter implements ExpandableListView.OnChildClickListener {

    public static final int CHILDVIEW_GRIDE = 1;
    public static final int CHILDVIEW_LISTITEM = 2;
    private ArrayList<String> groupData;
    private ArrayList<ArrayList> childrenData;
    private Context context;
    private ExpandableListView listView;
    private LayoutInflater inflater;

    private int groupId = 0;


    public TaskExpandableAdapterB(ArrayList<String> groupData, ArrayList<ArrayList> childrenData
            , Context context, ExpandableListView listView) {
        this.groupData = groupData;
        this.childrenData = childrenData;
        this.context = context;
        this.listView = listView;
        inflater = LayoutInflater.from(this.context);
        listView.setOnChildClickListener(this);
    }

    public int getChildType(int groupPosition, int childPosition) {

        if (TaskDetailsManager.PACKITEMFLAG.equals(groupData.get(groupPosition))) {
            return CHILDVIEW_GRIDE;
        } else {
            return CHILDVIEW_LISTITEM;
        }
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return childrenData.get(groupPosition).get(childPosition);
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }


    @Override
    public View getChildView(int groupPosition, final int childPosition,
                             boolean isLastChild, View convertView, ViewGroup parent) {
        int childViewType = getChildType(groupPosition, childPosition);
        ViewHolder holder = null;
        ViewHolderB holderB = null;

        switch (childViewType) {
            case CHILDVIEW_GRIDE:
                if (convertView == null||(ViewHolderB) convertView.getTag(R.id.tag_first)==null) {
                    convertView = inflater.inflate(R.layout.view_order_details_child_b, null);
                    holderB = new ViewHolderB(convertView);
                    convertView.setTag(R.id.tag_first, holderB);
                } else {
                    holderB = (ViewHolderB) convertView.getTag(R.id.tag_first);
                }

                ArrayList list = (ArrayList) (childrenData.get(groupPosition)).get(0);
                if (list == null || list.size() < 1) {
                    holderB.gvDetails.setVisibility(View.GONE);
                    holderB.tvEmpty.setVisibility(View.VISIBLE);
                } else {
                    holderB.gvDetails.setVisibility(View.VISIBLE);
                    holderB.tvEmpty.setVisibility(View.GONE);
                    holderB.gvDetails.setNumColumns(MyGrideListAdapter.NUMCOLUMNS);
                    MyGrideListAdapter myGrideListAdapter = new MyGrideListAdapter(context, list);
                    holderB.gvDetails.setAdapter(myGrideListAdapter);
                    MyGrideListAdapter.setGridViewHeight(context, myGrideListAdapter, holderB.gvDetails);
                }

                break;
            case CHILDVIEW_LISTITEM:
                if (convertView == null||(ViewHolder) convertView.getTag(R.id.tag_second)==null) {
                    convertView = inflater.inflate(R.layout.view_order_details_child, null);
                    holder = new ViewHolder(convertView);
                    convertView.setTag(R.id.tag_second, holder);
                } else {
                    holder = (ViewHolder) convertView.getTag(R.id.tag_second);
                }

                HashMap<String, String> map = (HashMap<String, String>) childrenData.get(groupPosition).get(childPosition);
                String productName = map.get("product_name");
                String rulesName = map.get("rules_name");
                String remarks = null;
                if (!productName.contains("订单号 ")) {
                    Utils.setDrawableImage(context, holder.orderDetailsChildProductName, 0);
                    if (!TextUtils.isEmpty(rulesName)) {
                        productName = productName + " ( " + rulesName + " )";
                    }
                } else {
                    remarks = setSettingOrderProcess(productName, holder.orderDetailsChildProductName, 1);
                }
                setSettingRemarks(holder.orderDetailsChildSremarks, remarks);
                holder.orderDetailsChildProductName.setText(productName);
                holder.orderDetailsChildLibraryName.setText("库位号 " + map.get("library_name"));
                holder.orderDetailsChildNumber.setText(map.get("number"));
                holder.orderDetailsChildNumber.setTextColor(Color.parseColor("#cf3b3d"));
                Utils.setDrawableImage(context, holder.orderDetailsChildNumber, 0);

                if (Constants.TaskTypeParams.TASK_TYPE_FLAG == Constants.TaskTypeParams.TASK_TYPE_THREE) {
                    String str = map.get("totle_packed") == null ? "0" : map.get("totle_packed");
                    if (str.equals(map.get("number"))) {
                        holder.orderDetailsChildNumber.setText("");
                        Utils.setDrawableImage(context, holder.orderDetailsChildNumber, R.drawable.ic_task_complete);
                    } else {
                        holder.orderDetailsChildNumber.setText(str + "/" + map.get("number"));
                    }
                } else {
                    int scanningNumber = Integer.parseInt(map.get("scanning_number"));
                    if (scanningNumber != 0) {
                        if (scanningNumber == Integer.parseInt(map.get("number"))) {
                            holder.orderDetailsChildNumber.setText("");
                            Utils.setDrawableImage(context, holder.orderDetailsChildNumber, R.drawable.ic_task_complete);
                        } else {
                            if (scanningNumber > 0) {
                                holder.orderDetailsChildNumber.setText(scanningNumber + "/" + map.get("number"));
                            } else
                                holder.orderDetailsChildNumber.setText(map.get("number"));
                        }
                    }
                }

                if (childPosition == (getChildrenCount(groupPosition) - 1)) {
                    holder.orderDetailsChildDivider.setVisibility(View.INVISIBLE);
                    holder.orderDetailsChildLayout.setBackgroundResource(R.drawable.bg_task_detail_bottom);
                } else {
                    holder.orderDetailsChildDivider.setVisibility(View.VISIBLE);
                    holder.orderDetailsChildLayout.setBackgroundResource(R.drawable.bg_task_detail_center);
                }


                break;
        }
        return convertView;
    }


    static class ViewHolder {

        @InjectView(R.id.order_details_child_product_name)
        TextView orderDetailsChildProductName;
        @InjectView(R.id.order_details_child_library_name)
        TextView orderDetailsChildLibraryName;
        @InjectView(R.id.order_details_child_number)
        DrawableCenterTextView orderDetailsChildNumber;
        @InjectView(R.id.order_details_child_layout)
        LinearLayout orderDetailsChildLayout;
        @InjectView(R.id.order_details_child_divider)
        View orderDetailsChildDivider;
        @InjectView(R.id.order_details_child_sremarks)
        ImageView orderDetailsChildSremarks;

        ViewHolder(View view) {
            ButterKnife.inject(this, view);
        }
    }

    static class ViewHolderB {
        @InjectView(R.id.gv_details)
        GridView gvDetails;
        @InjectView(R.id.tv_empty)
        TextView tvEmpty;

        ViewHolderB(View view) {
            ButterKnife.inject(this, view);
        }

    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return childrenData.get(groupPosition).size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return groupData.get(groupPosition);
    }

    @Override
    public int getGroupCount() {
        return groupData.size();
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded,
                             View convertView, ViewGroup parent) {
        ViewHolderGroup viewHolderGroup;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.view_order_details_group, null);
            viewHolderGroup = new ViewHolderGroup(convertView);
            convertView.setTag(R.id.tag_first, viewHolderGroup);
        } else {
            viewHolderGroup = (ViewHolderGroup) convertView.getTag(R.id.tag_first);
        }
        String groupName = groupData.get(groupPosition);
//        备注
        String remarks = null;
        if (groupName.contains("订单号")) {
            remarks = setSettingOrderProcess(groupName, viewHolderGroup.orderDetailsGroupName, 0);
            viewHolderGroup.orderDetailsGroupOdemtocal.setVisibility(View.GONE);
        } else {
            Utils.setDrawableImage(context, viewHolderGroup.orderDetailsGroupName, 0);
            groupName = "\n" + groupName;
            viewHolderGroup.orderDetailsGroupOdemtocal.setVisibility(View.VISIBLE);
        }
        if (TaskDetailsManager.PACKITEMFLAG.equals(groupName.trim())) {
            viewHolderGroup.tvDivider.setVisibility(View.GONE);
//            设置已打包图标
            viewHolderGroup.orderDetailsGroupOdemtocal.setImageResource(R.drawable.ic_already_packed);

            viewHolderGroup.linContent.setVisibility(View.VISIBLE);
            viewHolderGroup.linFrame.setVisibility(View.GONE);
        }
//         设置订单备注图标的隐藏或显示
        setSettingRemarks(viewHolderGroup.orderDetailsGroupSremarks, remarks);
        viewHolderGroup.orderDetailsGroupName.setText(groupName);
        convertView.setTag(R.id.tag_second, remarks);
        return convertView;
    }

    class ViewHolderGroup {

        @InjectView(R.id.order_details_group_odemtocal)
        ImageView orderDetailsGroupOdemtocal;
        @InjectView(R.id.order_details_group_name)
        TextView orderDetailsGroupName;
        @InjectView(R.id.order_details_group_sremarks)
        ImageView orderDetailsGroupSremarks;
        @InjectView(R.id.tv_divider)
        View tvDivider;
        @InjectView(R.id.lin_content)
        LinearLayout linContent;
        @InjectView(R.id.lin_frame)
        LinearLayout linFrame;

        ViewHolderGroup(View view) {
            ButterKnife.inject(this, view);
        }
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

    @Override
    public boolean onChildClick(ExpandableListView expandableListView, View view, int groupPosition, int childPosition, long l) {
        expandableListView.setItemChecked(expandableListView.getPositionForView(view), true);
        groupId = groupPosition;
        return false;
    }

    /**
     * 设置任务类型图标
     *
     * @param type 0 标题图标 1 子项图标
     */
    private String setSettingOrderProcess(String groupName, TextView textView, int type) {
//        用订单号查询任务表
        HashMap<String, String> map = DBUtils.getTaskInfo(context, groupName.split(" ")[1]);
        int processId = Integer.parseInt(map.get("process_id"));
        String remarks = map.get("descr");
        if (type == 0) {
            Utils.setDrawableImage(context, textView, Utils.getTaskDrawableByProcessId(processId));
        } else {
            Utils.setDrawableImage(context, textView, Utils.getTaskDrawableByProcessIds(processId));
        }
        return remarks;
    }

    /**
     * 设置订单备注 图标
     */
    private void setSettingRemarks(ImageView imageView, String remarks) {
        if (!TextUtils.isEmpty(remarks)) {

            imageView.setVisibility(View.VISIBLE);
        } else {
            imageView.setVisibility(View.INVISIBLE);
        }
    }


}
